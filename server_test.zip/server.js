const express = require('express');
const cors = require('cors'); // Import the CORS middleware
const fs = require('fs');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors()); // Enable CORS for all routes

// Endpoint to get high scores
app.get('/highscores', (req, res) => {
    // Read high scores from highscores.json
    fs.readFile('highscores.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading high scores file:', err);
            res.status(500).send('Internal server error');
            return;
        }
        const highScores = JSON.parse(data);
        res.json(highScores);
    });
});

// Endpoint to update high scores
app.post('/highscores', (req, res) => {
    const newHighScores = req.body;

    // Write new high scores to highscores.json
    fs.writeFile('highscores.json', JSON.stringify(newHighScores, null, 2), 'utf8', (err) => {
        if (err) {
            console.error('Error writing high scores file:', err);
            res.status(500).send('Internal server error');
            return;
        }
        res.send('High scores updated successfully');
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});